/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/

'use strict';
const http = require('http');
const request = require('request');
// const Alexa = require('alexa-sdk');
var AWS = require("aws-sdk");
var dynamodb = new AWS.DynamoDB.DocumentClient({
    region: "eu-west-1"
});

exports.handler = function (event, context, callback) {
    try {
        if (event.session.new) {

            if (event.request.type === 'LaunchRequest') {
                context.succeed(generateResponse(buildSpeechletResponse("Hi, I'm Bus Buddy", true), {}))
            }

            switch (event.request.intent.name) {

                case "GetNextBusIntent":
                    // console.log("Intent: ", event.request.intent.slots);
                    //   var busStopCode = event.request.intent.slots.busStopCode.value;
                    //   var busStopCode = 53444;
                    var napTanCode;
                    var params = {
                        TableName: 'userNaptanCode',
                        Key: {
                            'userId': event.session.user.userId
                        }
                    };
                    dynamodb.get(params, function (err, data) {
                        if (err) {
                            console.log("Failed to save naptan code" + err)
                        } else {
                            napTanCode = data.Item.napTanCode;
                            getApiData(napTanCode, function (jsonText) {
                                var station = jsonText[0]['stationName'];
                                var time = new Date(jsonText[0]['expectedArrival']).toLocaleTimeString();
                                var lineName = jsonText[0]['lineName'];
                                context.succeed(
                                    generateResponse(
                                        buildSpeechletResponse("Bus " + lineName + " will arrive at " + station + " stop at " + time, true), {})
                                )
                            });

                        }
                    });
                    // var napTanCode = '490010331E';
                    break;

                case "SetBusStopIntent":
                    var busStopCode = parseInt(event.request.intent.slots.busStopCode.value);
                    // var busStopCode = 53444;
                    getNapTanCode(busStopCode, function (napTanCode) {
                        getApiData(napTanCode, function (jsonText) {
                            var station = jsonText[0]['stationName'];
                            var time = new Date(jsonText[0]['expectedArrival']).toLocaleTimeString();
                            context.succeed(
                                generateResponse(
                                    buildSpeechletResponse("Your stop is set to " + station, true), {})
                            )
                        });

                        var params = {
                            TableName: 'userNaptanCode',
                            Item: {
                                userId: event.session.user.userId,
                                napTanCode: napTanCode
                            }
                        };
                        dynamodb.put(params, function (err, data) {
                            if (err) {
                                console.log("Failed to save naptan code: " + err)
                            } else {
                                console.log("Saved correctly")
                            }

                        });
                    });
                    break;
                case "GetStopBusesIntent":
                    var params = {
                        TableName: 'userNaptanCode',
                        Key: {
                            'userId': event.session.user.userId
                        }
                    };
                    dynamodb.get(params, function (err, data) {
                        if (err) {
                            console.log("Failed to get naptan code: " + err)
                        } else {
                            getApiData(data.Item.napTanCode, function (arrivals) {
                                var busesText = getStopBusesText(arrivals)
                                context.succeed(
                                    generateResponse(
                                        buildSpeechletResponse("The buses that will be arriving at this station are" + busesText, true), {})
                                )
                            });

                        }
                    });
                    break;
                default:
                    context.fail('INVALID REQUEST TYPE: ${event.request.type}')
            }
        }
    } catch (error) {
        context.fail('exception ${error}' + error)
    }
};


var buildSpeechletResponse = (outputTest, shouldEndSession) => {
    return {
        outputSpeech: {
            type: "PlainText",
            text: outputTest
        },
        shouldEndSession: shouldEndSession
    }
}

var generateResponse = (speechletResponse, sessionAttributes) => {
    return {
        version: "1.0",
        sesionAttributes: sessionAttributes,
        response: speechletResponse
    }
}

function getNapTanCode(busStopCode, callAPI) {
    var result = false;

    var params = {
        TableName: 'busStopCodeLookupFull_v3',
        Key: {
            "busStopCode": busStopCode
        }
    };

    dynamodb.get(params, function (err, data) {
        if (err) {
            console.log(err + ' : ' + response.statusCode);
        } else {
            result = data.Item.naptanAtco;
            callAPI(result);
        }
    });
}

function getApiData(napTanCode, callback) {
    var url = 'https://api.tfl.gov.uk/StopPoint/' + napTanCode + '/arrivals'
    request(url, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            // from within the callback, write data to response, essentially returning it.
            var jsonText = JSON.parse(body);
            callback(jsonText);
        } else {
            console.log(error + ' : ' + response.statusCode);
        }
    });
}

function getStopBusesText(arrivals) {
    var buses = [];
    var result = '';

    arrivals.map(function (arrival) {
        buses.push(arrival.lineName);
    })
    buses = buses.filter(function (elem, index, self) {
        return index == self.indexOf(elem);
    })

    buses.forEach(function(item) {
        result += spellDigitOutput(item);
    });

    return result
}

function spellDigitOutput(number){
    return "<say-as interpret-as='digits'>" + number + "</say-as>";
}